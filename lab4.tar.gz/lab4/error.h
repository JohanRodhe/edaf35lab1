#ifndef error_h
#define error_h

void error(const char *fmt, ...);

#endif
